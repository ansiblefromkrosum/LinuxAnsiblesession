#!/usr/bin/python
import os
os.system("ps -f")
print("Running python PID:{}".format(os.getpid()))
